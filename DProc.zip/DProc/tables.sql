
PARTNER_BENEFICIARIES Table
CREATE TABLE PARTNER_BENEFICIARIES (
    BENEFICIARY_ID          NUMBER PRIMARY KEY,
    BENEFICIARY_VERSION     NUMBER,
    PARTNER_ID              NUMBER,
    BENEFICIARY_NAME        VARCHAR2(255),
    ACCOUNT_NO              VARCHAR2(50),
    ACCOUNT_TYPE            VARCHAR2(50),
    ADDRESS                 VARCHAR2(255),
    BANK_CODE               VARCHAR2(50),
    VERIFY_ID               VARCHAR2(50),
    VERIFY_INDICATOR        VARCHAR2(1),
    VERIFY_TYPE             VARCHAR2(50)
);

INSERT INTO PARTNER_BENEFICIARIES 
(BENEFICIARY_ID, BENEFICIARY_VERSION, PARTNER_ID, BENEFICIARY_NAME, ACCOUNT_NO, ACCOUNT_TYPE, ADDRESS, BANK_CODE, VERIFY_ID, VERIFY_INDICATOR, VERIFY_TYPE)
VALUES 
(1, 1, 101, 'John Doe', '123456789', 'Savings', '123 Elm Street', 'BANK01', 'VERIFY123', 'Y', 'TypeA'),
(2, 1, 102, 'Jane Smith', '987654321', 'Checking', '456 Oak Avenue', 'BANK02', 'VERIFY456', 'N', 'TypeB'),
(3, 1, 103, 'Alice Johnson', '112233445', 'Savings', '789 Pine Road', 'BANK03', 'VERIFY789', 'Y', 'TypeA'),
(4, 1, 104, 'Bob Brown', '998877665', 'Checking', '321 Maple Lane', 'BANK04', 'VERIFY321', 'N', 'TypeB'),
(5, 1, 105, 'Charlie Green', '554433221', 'Savings', '654 Cedar Avenue', 'BANK05', 'VERIFY654', 'Y', 'TypeA'),
(6, 1, 106, 'Diana Prince', '667788990', 'Checking', '987 Birch Street', 'BANK06', 'VERIFY987', 'N', 'TypeB'),
(7, 1, 107, 'Eve Adams', '123123123', 'Savings', '135 Spruce Road', 'BANK07', 'VERIFY135', 'Y', 'TypeA'),
(8, 1, 108, 'Frank White', '321321321', 'Checking', '246 Willow Lane', 'BANK08', 'VERIFY246', 'N', 'TypeB'),
(9, 1, 109, 'Grace Black', '456456456', 'Savings', '357 Aspen Avenue', 'BANK09', 'VERIFY357', 'Y', 'TypeA');

------------------------------------------------------------------------------------------------------------------------------------------------

PARTNER_BENEFICIARY_HISTORY Table
CREATE TABLE PARTNER_BENEFICIARY_HISTORY (
    BENEFICIARY_ID          NUMBER,
    BENEFICIARY_VERSION     NUMBER,
    PARTNER_ID              NUMBER,
    BENEFICIARY_NAME        VARCHAR2(255),
    ACCOUNT_NO              VARCHAR2(50),
    ACCOUNT_TYPE            VARCHAR2(50),
    ADDRESS                 VARCHAR2(255),
    BANK_CODE               VARCHAR2(50),
    VERIFY_ID               VARCHAR2(50),
    VERIFY_INDICATOR        VARCHAR2(1),
    VERIFY_TYPE             VARCHAR2(50)
);

INSERT INTO PARTNER_BENEFICIARY_HISTORY 
(BENEFICIARY_ID, BENEFICIARY_VERSION, PARTNER_ID, BENEFICIARY_NAME, ACCOUNT_NO, ACCOUNT_TYPE, ADDRESS, BANK_CODE, VERIFY_ID, VERIFY_INDICATOR, VERIFY_TYPE)
VALUES 
(1, 0, 101, 'John Doe', '123456789', 'Savings', '123 Elm Street', 'BANK01', 'VERIFY123', 'Y', 'TypeA'),
(2, 0, 102, 'Jane Smith', '987654321', 'Checking', '456 Oak Avenue', 'BANK02', 'VERIFY456', 'N', 'TypeB'),
(3, 0, 103, 'Alice Johnson', '112233445', 'Savings', '789 Pine Road', 'BANK03', 'VERIFY789', 'Y', 'TypeA'),
(4, 0, 104, 'Bob Brown', '998877665', 'Checking', '321 Maple Lane', 'BANK04', 'VERIFY321', 'N', 'TypeB'),
(5, 0, 105, 'Charlie Green', '554433221', 'Savings', '654 Cedar Avenue', 'BANK05', 'VERIFY654', 'Y', 'TypeA'),
(6, 0, 106, 'Diana Prince', '667788990', 'Checking', '987 Birch Street', 'BANK06', 'VERIFY987', 'N', 'TypeB'),
(7, 0, 107, 'Eve Adams', '123123123', 'Savings', '135 Spruce Road', 'BANK07', 'VERIFY135', 'Y', 'TypeA'),
(8, 0, 108, 'Frank White', '321321321', 'Checking', '246 Willow Lane', 'BANK08', 'VERIFY246', 'N', 'TypeB'),
(9, 0, 109, 'Grace Black', '456456456', 'Savings', '357 Aspen Avenue', 'BANK09', 'VERIFY357', 'Y', 'TypeA');

------------------------------------------------------------------------------------------------------------------------------------------------

BANK_DETAILS Table
CREATE TABLE BANK_DETAILS (
    DETAIL_ID               NUMBER PRIMARY KEY,
    PROFILE_CODE            VARCHAR2(50),
    PROFILE_KEY             VARCHAR2(50),
    BENEFICIARY_ID          NUMBER,
    BENEFICIARY_VERSION     NUMBER,
    BENEFICIARY_NAME        VARCHAR2(255),
    ACCOUNT_NO              VARCHAR2(50),
    ACCOUNT_TYPE            VARCHAR2(50),
    ADDRESS                 VARCHAR2(255),
    BANK_CODE               VARCHAR2(50),
    VERIFY_ID               VARCHAR2(50),
    VERIFY_INDICATOR        VARCHAR2(1),
    VERIFY_TYPE             VARCHAR2(50),
    CHANGE_LOG              VARCHAR2(32000),
    OPERATOR                VARCHAR2(50),
    STATUS                  VARCHAR2(1),
    TRANSACTION_DATE        DATE
);

INSERT INTO BANK_DETAILS 
(DETAIL_ID, PROFILE_CODE, PROFILE_KEY, BENEFICIARY_ID, BENEFICIARY_VERSION, BENEFICIARY_NAME, ACCOUNT_NO, ACCOUNT_TYPE, ADDRESS, BANK_CODE, VERIFY_ID, VERIFY_INDICATOR, VERIFY_TYPE, CHANGE_LOG, OPERATOR, STATUS, TRANSACTION_DATE)
VALUES 
(1, 'PROF01', 'KEY01', 1, 1, 'John Doe', '123456789', 'Savings', '123 Elm Street', 'BANK01', 'VERIFY123', 'Y', 'TypeA', 'Initial Entry', 'Admin', 'P', SYSDATE),
(2, 'PROF02', 'KEY02', 2, 1, 'Jane Smith', '987654321', 'Checking', '456 Oak Avenue', 'BANK02', 'VERIFY456', 'N', 'TypeB', 'Initial Entry', 'Admin', 'P', SYSDATE),
(3, 'PROF03', 'KEY03', 3, 1, 'Alice Johnson', '112233445', 'Savings', '789 Pine Road', 'BANK03', 'VERIFY789', 'Y', 'TypeA', 'Initial Entry', 'Admin', 'P', SYSDATE),
(4, 'PROF04', 'KEY04', 4, 1, 'Bob Brown', '998877665', 'Checking', '321 Maple Lane', 'BANK04', 'VERIFY321', 'N', 'TypeB', 'Initial Entry', 'Admin', 'P', SYSDATE),
(5, 'PROF05', 'KEY05', 5, 1, 'Charlie Green', '554433221', 'Savings', '654 Cedar Avenue', 'BANK05', 'VERIFY654', 'Y', 'TypeA', 'Initial Entry', 'Admin', 'P', SYSDATE),
(6, 'PROF06', 'KEY06', 6, 1, 'Diana Prince', '667788990', 'Checking', '987 Birch Street', 'BANK06', 'VERIFY987', 'N', 'TypeB', 'Initial Entry', 'Admin', 'P', SYSDATE),
(7, 'PROF07', 'KEY07', 7, 1, 'Eve Adams', '123123123', 'Savings', '135 Spruce Road', 'BANK07', 'VERIFY135', 'Y', 'TypeA', 'Initial Entry', 'Admin', 'P', SYSDATE),
(8, 'PROF08', 'KEY08', 8, 1, 'Frank White', '321321321', 'Checking', '246 Willow Lane', 'BANK08', 'VERIFY246', 'N', 'TypeB', 'Initial Entry', 'Admin', 'P', SYSDATE),
(9, 'PROF09', 'KEY09', 9, 1, 'Grace Black', '456456456', 'Savings', '357 Aspen Avenue', 'BANK09', 'VERIFY357', 'Y', 'TypeA', 'Initial Entry', 'Admin', 'P', SYSDATE);

----------------------------------------------------------------------------------------------------------------------------------

PROFILE_ACCESS Table
CREATE TABLE PROFILE_ACCESS (
    ACCESS_ID               NUMBER PRIMARY KEY,
    USER_ID                 NUMBER,
    ACCESS_PROFILE          VARCHAR2(50),
    ACCESS_TYPE             VARCHAR2(50)
);

INSERT INTO PROFILE_ACCESS 
(ACCESS_ID, USER_ID, ACCESS_PROFILE, ACCESS_TYPE)
VALUES 
(1, 201, 'PROF01', 'BENEFICIARY_EDIT'),
(2, 202, 'PROF02', 'BENEFICIARY_VIEW'),
(3, 203, 'PROF03', 'BENEFICIARY_EDIT'),
(4, 204, 'PROF04', 'BENEFICIARY_VIEW'),
(5, 205, 'PROF05', 'BENEFICIARY_EDIT'),
(6, 206, 'PROF06', 'BENEFICIARY_VIEW'),
(7, 207, 'PROF07', 'BENEFICIARY_EDIT'),
(8, 208, 'PROF08', 'BENEFICIARY_VIEW'),
(9, 209, 'PROF09', 'BENEFICIARY_EDIT');

----------------------------------------------------------------------------------------------------------------------------------------------------------------

EMAIL_TEMPLATES Table
CREATE TABLE EMAIL_TEMPLATES (
    TEMPLATE_ID             NUMBER PRIMARY KEY,
    TEMPLATE_CODE           VARCHAR2(50),
    SUBJECT                 VARCHAR2(255),
    CONTENT                 CLOB
);


INSERT INTO EMAIL_TEMPLATES 
(TEMPLATE_ID, TEMPLATE_CODE, SUBJECT, CONTENT)
VALUES 
(1, 'WELCOME', 'Welcome to Our Service', 'Dear {Name}, welcome to our service.'),
(2, 'REMINDER', 'Payment Reminder', 'Dear {Name}, this is a reminder for your upcoming payment.'),
(3, 'THANK_YOU', 'Thank You', 'Dear {Name}, thank you for your business.'),
(4, 'INVOICE', 'Invoice Available', 'Dear {Name}, your invoice is now available.'),
(5, 'ALERT', 'Important Alert', 'Dear {Name}, please be aware of the following alert.'),
(6, 'UPDATE', 'Service Update', 'Dear {Name}, here is an update about our services.'),
(7, 'NOTIFICATION', 'New Notification', 'Dear {Name}, you have a new notification.'),
(8, 'CONFIRMATION', 'Confirmation Required', 'Dear {Name}, please confirm your details.'),
(9, 'CANCELLATION', 'Cancellation Notice', 'Dear {Name}, your service has been cancelled.');

------------------------------------------------------------------------------------------------------------------------

MAIL_QUEUE Table
CREATE TABLE MAIL_QUEUE (
    MAIL_ID                 NUMBER PRIMARY KEY,
    MAIL_TYPE               VARCHAR2(50),
    SUBJECT                 VARCHAR2(255),
    CONTENT                 CLOB,
    CREATED_BY              VARCHAR2(50),
    REF_NO                  VARCHAR2(50),
    PROCESS_TYPE            VARCHAR2(50),
    MAIL_STATUS             VARCHAR2(1)

);

INSERT INTO MAIL_QUEUE 
(MAIL_ID, MAIL_TYPE, SUBJECT, CONTENT, CREATED_BY, REF_NO, PROCESS_TYPE, MAIL_STATUS)
VALUES 
(1, 'EMAIL', 'Welcome to Our Service', 'Dear John Doe, welcome to our service.', 'System', 'REF001', 'TypeA', 'N'),
(2, 'EMAIL', 'Payment Reminder', 'Dear Jane Smith, this is a reminder for your upcoming payment.', 'System', 'REF002', 'TypeB', 'N'),
(3, 'EMAIL', 'Thank You', 'Dear Alice Johnson, thank you for your business.', 'System', 'REF003', 'TypeA', 'N'),
(4, 'EMAIL', 'Invoice Available', 'Dear Bob Brown, your invoice is now available.', 'System', 'REF004', 'TypeB', 'N'),
(5, 'EMAIL', 'Important Alert', 'Dear Charlie Green, please be aware of the following alert.', 'System', 'REF005', 'TypeA', 'N'),
(6, 'EMAIL', 'Service Update', 'Dear Diana Prince, here is an update about our services.', 'System', 'REF006', 'TypeB', 'N'),
(7, 'EMAIL', 'New Notification', 'Dear Eve Adams, you have a new notification.', 'System', 'REF007', 'TypeA', 'N'),
(8, 'EMAIL', 'Confirmation Required', 'Dear Frank White, please confirm your details.', 'System', 'REF008', 'TypeB', 'N'),
(9, 'EMAIL', 'Cancellation Notice', 'Dear Grace Black, your service has been cancelled.', 'System', 'REF009', 'TypeA', 'N');

------------------------------------------------------------------------------------------------------------------------

MAIL_RECIPIENTS Table
CREATE TABLE MAIL_RECIPIENTS (
    RECIPIENT_ID            NUMBER PRIMARY KEY,
    MAIL_ID                 NUMBER,
    RECIPIENT_TYPE          VARCHAR2(3),
    EMAIL_ADDRESS           VARCHAR2(255),
    FOREIGN KEY (MAIL_ID) REFERENCES MAIL_QUEUE(MAIL_ID)

);

INSERT INTO MAIL_RECIPIENTS (RECIPIENT_ID, MAIL_ID, RECIPIENT_TYPE, EMAIL_ADDRESS)
VALUES
    (1, 1, 'TO', 'john.doe@example.com'),
    (2, 2, 'TO', 'jane.smith@example.com'),
    (3, 3, 'TO', 'alice.johnson@example.com'),
    (4, 4, 'TO', 'bob.brown@example.com'),
    (5, 5, 'TO', 'charlie.green@example.com'),
    (6, 6, 'TO', 'diana.prince@example.com'),
    (7, 7, 'TO', 'eve.adams@example.com'),
    (8, 8, 'TO', 'frank.white@example.com'),
    (9, 9, 'TO', 'grace.black@example.com');

------------------------------------------------------------------------------------------------------------

CREATE TABLE EXTERNAL_PARTNERS (
    PARTNER_ID            NUMBER PRIMARY KEY,
    EXT_PARTNER_ID        NUMBER,
    EXT_VERSION           NUMBER,
    EXT_CODE              VARCHAR2(50),
    EXT_TYPE              VARCHAR2(50),
    PARTNER_NAME          VARCHAR2(255),
    CREATED_DATE          DATE,
    UPDATED_DATE          DATE
);


INSERT INTO EXTERNAL_PARTNERS (PARTNER_ID, EXT_PARTNER_ID, EXT_VERSION, EXT_CODE, EXT_TYPE, PARTNER_NAME, CREATED_DATE, UPDATED_DATE)
VALUES
    (101, 1001, 1, 'EXT001', 'TypeA', 'External Partner A', SYSDATE - 100, SYSDATE),
    (102, 1002, 1, 'EXT002', 'TypeB', 'External Partner B', SYSDATE - 200, SYSDATE),
    (103, 1003, 1, 'EXT003', 'TypeA', 'External Partner C', SYSDATE - 300, SYSDATE),
    (104, 1004, 1, 'EXT004', 'TypeB', 'External Partner D', SYSDATE - 400, SYSDATE),
    (105, 1005, 1, 'EXT005', 'TypeA', 'External Partner E', SYSDATE - 500, SYSDATE),
    (106, 1006, 1, 'EXT006', 'TypeB', 'External Partner F', SYSDATE - 600, SYSDATE),
    (107, 1007, 1, 'EXT007', 'TypeA', 'External Partner G', SYSDATE - 700, SYSDATE),
    (108, 1008, 1, 'EXT008', 'TypeB', 'External Partner H', SYSDATE - 800, SYSDATE),
    (109, 1009, 1, 'EXT009', 'TypeA', 'External Partner I', SYSDATE - 900, SYSDATE);
