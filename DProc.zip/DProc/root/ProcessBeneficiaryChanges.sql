PROCEDURE ProcessBeneficiaryChanges (
    partnerId            IN     EXTERNAL_PARTNERS.PARTNER_ID%TYPE,
    updatedByUser        IN     EXTERNAL_PARTNERS.UPDATED_BY%TYPE,
    extPartnerId         IN     EXTERNAL_PARTNERS.EXT_PARTNER_ID%TYPE,
    extVersion           IN     EXTERNAL_PARTNERS.EXT_VERSION%TYPE,
    extCode              IN     EXTERNAL_PARTNERS.EXT_CODE%TYPE,
    extType              IN     EXTERNAL_PARTNERS.EXT_TYPE%TYPE,
    extBeneficiaryId     IN     EXTERNAL_PARTNERS.BENEFICIARY_ID%TYPE,
    extBeneficiaryVersion IN    EXTERNAL_PARTNERS.BENEFICIARY_VERSION%TYPE,
    newBeneficiaryId     IN     EXTERNAL_PARTNERS.BENEFICIARY_ID%TYPE,
    newBeneficiaryVersion IN    EXTERNAL_PARTNERS.BENEFICIARY_VERSION%TYPE,
    operationResult      OUT VARCHAR2
) IS
    CURSOR curNewBeneficiary IS
        SELECT * FROM PARTNER_BENEFICIARIES WHERE beneficiary_id = newBeneficiaryId AND beneficiary_version = newBeneficiaryVersion;

    CURSOR curExistingBeneficiary IS
        SELECT * FROM PARTNER_BENEFICIARY_HISTORY WHERE beneficiary_id = newBeneficiaryId AND beneficiary_version = newBeneficiaryVersion;

    recNewBeneficiary     curNewBeneficiary%ROWTYPE;
    recExistingBeneficiary curExistingBeneficiary%ROWTYPE;
    accessCount           NUMBER;
    changeLog             BANK_DETAILS.CHANGE_LOG%TYPE := NULL;
    emailResult           NUMBER;
    logMessage            VARCHAR2(200);
    procedureTag          CONSTANT VARCHAR2(30) := 'ProcessBeneficiaryChanges';

    PROCEDURE WriteLog(msg IN VARCHAR2) IS
    BEGIN
        log_util.record_log(gv_pkgName || '-' || procedureTag, partnerId, msg);
    END WriteLog;

    FUNCTION CheckUserAccess RETURN BOOLEAN IS
    BEGIN
        SELECT COUNT(1) INTO accessCount
        FROM PROFILE_ACCESS
        WHERE access_type = 'BENEFICIARY_EDIT' AND USER_ID = updatedByUser AND ACCESS_PROFILE = extType;
        RETURN accessCount > 0;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN FALSE;
    END CheckUserAccess;

    PROCEDURE AddBeneficiaryData IS
    BEGIN
        OPEN curNewBeneficiary;
        FETCH curNewBeneficiary INTO recNewBeneficiary;
        IF curNewBeneficiary%NOTFOUND THEN
            WriteLog('No new beneficiary data found.');
            CLOSE curNewBeneficiary;
            RETURN;
        END IF;

        -- Construct change log
        IF recNewBeneficiary.BENEFICIARY_NAME IS NOT NULL THEN
            changeLog := changeLog || 'Beneficiary Name Updated As ' || recNewBeneficiary.BENEFICIARY_NAME || CHR(10);
        END IF;
        -- Repeat for other fields as needed...

        INSERT INTO BANK_DETAILS (
            PROFILE_CODE, PROFILE_KEY, BENEFICIARY_ID, BENEFICIARY_VERSION, BENEFICIARY_NAME,
            EXT_PARTNER_ID, EXT_VERSION, ACCOUNT_NO, ACCOUNT_TYPE, ADDRESS,
            BANK_CODE, VERIFY_ID, VERIFY_INDICATOR, VERIFY_TYPE, CHANGE_LOG,
            OPERATOR, STATUS, TRANSACTION_DATE
        ) VALUES (
            extType, extCode, recNewBeneficiary.BENEFICIARY_ID, recNewBeneficiary.BENEFICIARY_VERSION, recNewBeneficiary.BENEFICIARY_NAME,
            extPartnerId, extVersion, recNewBeneficiary.ACCOUNT_NO, recNewBeneficiary.ACCOUNT_TYPE, recNewBeneficiary.ADDRESS,
            recNewBeneficiary.BANK_CODE, recNewBeneficiary.VERIFY_ID, recNewBeneficiary.VERIFY_INDICATOR, recNewBeneficiary.VERIFY_TYPE, changeLog,
            updatedByUser, 'P', SYSDATE
        );

        emailResult := NotifyByEmail(extType, extCode, partnerId);
        operationResult := 'SUCCESS';
        WriteLog('Beneficiary details inserted successfully.');
        CLOSE curNewBeneficiary;
    END AddBeneficiaryData;

    PROCEDURE LogBeneficiaryDifferences IS
    BEGIN
        OPEN curExistingBeneficiary;
        FETCH curExistingBeneficiary INTO recExistingBeneficiary;
        IF curExistingBeneficiary%NOTFOUND THEN
            WriteLog('No existing beneficiary data found.');
            CLOSE curExistingBeneficiary;
            RETURN;
        END IF;

        OPEN curNewBeneficiary;
        FETCH curNewBeneficiary INTO recNewBeneficiary;
        IF curNewBeneficiary%NOTFOUND THEN
            WriteLog('No new beneficiary data found.');
            CLOSE curNewBeneficiary;
            RETURN;
        END IF;

        -- Compare and log differences
        IF recExistingBeneficiary.BENEFICIARY_NAME <> recNewBeneficiary.BENEFICIARY_NAME THEN
            changeLog := 'Beneficiary Name Changed From ' || recExistingBeneficiary.BENEFICIARY_NAME || ' to ' || recNewBeneficiary.BENEFICIARY_NAME || CHR(10);
        END IF;
        -- Repeat for other fields as needed...

        INSERT INTO BANK_DETAILS (
            PROFILE_CODE, PROFILE_KEY, OLD_BENEFICIARY_ID, OLD_BENEFICIARY_VERSION, OLD_BENEFICIARY_NAME,
            OLD_BANK_CODE, OLD_ADDRESS, OLD_ACCOUNT_TYPE, OLD_ACCOUNT_NO, OLD_VERIFY_INDICATOR,
            OLD_VERIFY_TYPE, OLD_VERIFY_ID, BENEFICIARY_ID, BENEFICIARY_VERSION, BENEFICIARY_NAME,
            BANK_CODE, ADDRESS, ACCOUNT_TYPE, ACCOUNT_NO, VERIFY_INDICATOR,
            VERIFY_TYPE, VERIFY_ID, STATUS, CHANGE_LOG, TRANSACTION_DATE,
            OPERATOR, EXT_PARTNER_ID, EXT_VERSION
        ) VALUES (
            extType, extCode, recExistingBeneficiary.BENEFICIARY_ID, recExistingBeneficiary.BENEFICIARY_VERSION, recExistingBeneficiary.BENEFICIARY_NAME,
            recExistingBeneficiary.BANK_CODE, recExistingBeneficiary.ADDRESS, recExistingBeneficiary.ACCOUNT_TYPE, recExistingBeneficiary.ACCOUNT_NO, recExistingBeneficiary.VERIFY_INDICATOR,
            recExistingBeneficiary.VERIFY_TYPE, recExistingBeneficiary.VERIFY_ID, recNewBeneficiary.BENEFICIARY_ID, recNewBeneficiary.BENEFICIARY_VERSION, recNewBeneficiary.BENEFICIARY_NAME,
            recNewBeneficiary.BANK_CODE, recNewBeneficiary.ADDRESS, recNewBeneficiary.ACCOUNT_TYPE, recNewBeneficiary.ACCOUNT_NO, recNewBeneficiary.VERIFY_INDICATOR,
            recNewBeneficiary.VERIFY_TYPE, recNewBeneficiary.VERIFY_ID, 'P', changeLog, SYSDATE,
            updatedByUser, extPartnerId, extVersion
        );

        emailResult := NotifyByEmail(extType, extCode, partnerId);
        operationResult := 'SUCCESS';
        WriteLog('Beneficiary details updated successfully.');
        CLOSE curExistingBeneficiary;
        CLOSE curNewBeneficiary;
    END LogBeneficiaryDifferences;

BEGIN
    WriteLog('Starting procedure with parameters: ' || partnerId || ', ' || updatedByUser || ', ' || extPartnerId);

    IF CheckUserAccess THEN
        IF extBeneficiaryId IS NULL THEN
            AddBeneficiaryData;
        ELSE
            LogBeneficiaryDifferences;
        END IF;
    ELSE
        operationResult := 'FAILED';
        WriteLog('No access for user: ' || updatedByUser);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        operationResult := 'FAILED';
        WriteLog('Error: ' || SQLERRM);
END ProcessBeneficiaryChanges;
