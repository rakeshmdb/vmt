FUNCTION NotifyByEmail (
    extType IN EXTERNAL_PARTNERS.EXT_TYPE%TYPE,
    extCode IN EXTERNAL_PARTNERS.EXT_CODE%TYPE,
    partnerId IN EXTERNAL_PARTNERS.PARTNER_ID%TYPE
) RETURN NUMBER IS
    funcName             VARCHAR2(30) := 'NotifyByEmail';
    stepIndicator        VARCHAR2(5) := '001';
    emailCount           NUMBER;
    emailSubject         VARCHAR2(100);
    emailContent         CLOB;
    partnerName          PARTNERS.NAME%TYPE;
    recipientList        MAIL_ENGINE.recipient_array := MAIL_ENGINE.recipient_array();
    recipientIndex       NUMBER(3) := 0;
    extTypeDescription   VARCHAR2(100);
    subjectParams        TEMPLATE_EXTRACTION.param_array := TEMPLATE_EXTRACTION.param_array();
BEGIN
    stepIndicator := '001';

    SELECT description
      INTO extTypeDescription
      FROM code_table
     WHERE category = 'EXTERNAL_TYPE' AND code = extType;

    SELECT name
      INTO partnerName
      FROM partners
     WHERE partner_id = partnerId;

    subjectParams := TEMPLATE_EXTRACTION.param_array(extTypeDescription, extCode, partnerName);
    emailSubject := TEMPLATE_EXTRACTION.GetSubject('EXTERNAL_TYPE', subjectParams);

    FOR userRecord IN (
        SELECT ACCESS.USER_ID, USER_PROFILE.EMAIL
          FROM ACCESS_PROFILE ACCESS
          JOIN USER_PROFILE ON ACCESS.USER_ID = USER_PROFILE.USER_ID
         WHERE ACCESS.PROFILE = extType
           AND ACCESS.TYPE = 'AUT'
           AND USER_PROFILE.email IS NOT NULL
           AND REGEXP_LIKE(USER_PROFILE.email, '^[a-z0-9!#$%&''*+/=?^_`{|}~-]+(\.[a-z0-9!#$%&''*+/=?^_`{|}~-]+)*@([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+([A-Z]{2,4})$', 'i')
    ) LOOP
        recipientList := MAIL_ENGINE.recipient_array();
        recipientIndex := 0;
        recipientIndex := recipientIndex + 1;
        recipientList.EXTEND;
        recipientList(recipientIndex) := userRecord.email;
        emailContent := TEMPLATE_EXTRACTION.GetContent('EXTERNAL_TYPE', subjectParams);
        stepIndicator := '005';
        emailCount := MAIL_ENGINE.InsertEmail(
            recipientList,
            NULL,  -- cc
            NULL,  -- bcc
            emailSubject,
            emailContent,
            '*SYSTEM',
            extType
        );
    END LOOP;

    RETURN emailCount;
EXCEPTION
    WHEN OTHERS THEN
        log_util.record_error(gv_pkgName || funcName, 1, extType || '::Step: ' || stepIndicator || '::' || SQLERRM);
        RETURN 0;
END NotifyByEmail;
