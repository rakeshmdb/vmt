FUNCTION InsertEmail (
    recipients          ARRAY_TYPE,
    ccRecipients        ARRAY_TYPE,
    bccRecipients       ARRAY_TYPE,
    emailSubject        VARCHAR2,
    emailContent        CLOB,
    createdBy           VARCHAR2,
    referenceNumber     VARCHAR2,
    processType      IN VARCHAR2 DEFAULT NULL,
    mailStatus       IN VARCHAR2 DEFAULT NULL
) RETURN NUMBER AS
    emailId          NUMBER;
    NoEmailException EXCEPTION;
    stepDescription  VARCHAR2(100);
BEGIN
    stepDescription := 'INSERT INTO QUEUE';

    INSERT INTO MAIL_QUEUE (
        MAIL_TYPE,
        SUBJECT,
        CONTENT,
        CREATED_BY,
        REF_NO,
        PROCESS_TYPE,
        MAIL_STATUS
    ) VALUES (
        'EMAIL',
        emailSubject,
        emailContent,
        createdBy,
        referenceNumber,
        processType,
        NVL(mailStatus, 'N')
    ) RETURNING MAIL_ID INTO emailId;

    stepDescription := 'INSERT RECIPIENTS';

    IF recipients IS NULL THEN
        RAISE NoEmailException;
    END IF;

    FOR i IN 1 .. recipients.COUNT LOOP
        INSERT INTO MAIL_RECIPIENTS (MAIL_ID, RECIPIENT_TYPE, EMAIL_ADDRESS)
        VALUES (emailId, 'TO', recipients(i));
    END LOOP;

    stepDescription := 'INSERT CC RECIPIENTS';

    IF ccRecipients IS NOT NULL THEN
        FOR i IN 1 .. ccRecipients.COUNT LOOP
            INSERT INTO MAIL_RECIPIENTS (MAIL_ID, RECIPIENT_TYPE, EMAIL_ADDRESS)
            VALUES (emailId, 'CC', ccRecipients(i));
        END LOOP;
    END IF;

    stepDescription := 'INSERT BCC RECIPIENTS';

    IF bccRecipients IS NOT NULL THEN
        FOR i IN 1 .. bccRecipients.COUNT LOOP
            INSERT INTO MAIL_RECIPIENTS (MAIL_ID, RECIPIENT_TYPE, EMAIL_ADDRESS)
            VALUES (emailId, 'BCC', bccRecipients(i));
        END LOOP;
    END IF;

    RETURN emailId;
EXCEPTION
    WHEN NoEmailException THEN
        log_util.record_error(
            'MAIL_ENGINE.InsertEmail',
            1,
            'Step: ' || stepDescription || '::' || SQLERRM
        );
        RAISE_APPLICATION_ERROR(-20000, 'Recipient Email is undefined.' || SQLERRM);
    WHEN OTHERS THEN
        log_util.record_error(
            'MAIL_ENGINE.InsertEmail',
            1,
            'Step: ' || stepDescription || '::' || SQLERRM
        );
        RAISE_APPLICATION_ERROR(-20000, 'Unhandled Error.' || SQLERRM);
END InsertEmail;
