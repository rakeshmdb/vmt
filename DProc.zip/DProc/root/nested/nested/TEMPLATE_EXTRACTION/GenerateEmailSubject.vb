FUNCTION GenerateEmailSubject (
    templateCode VARCHAR2,
    subjectParams ARRAY_TYPE
) RETURN VARCHAR2 AS
    subjectText         EMAIL_TEMPLATES.SUBJECT%TYPE;
    backupSubjectText   VARCHAR2(32000);
BEGIN
    SELECT SUBJECT
      INTO subjectText
      FROM EMAIL_TEMPLATES
     WHERE TEMPLATE_CODE = templateCode;

    backupSubjectText := subjectText;
    subjectText := ProcessDynamicFields(subjectText, subjectParams);
    RETURN subjectText;
EXCEPTION
    WHEN OTHERS THEN
        RETURN backupSubjectText;
END GenerateEmailSubject;
