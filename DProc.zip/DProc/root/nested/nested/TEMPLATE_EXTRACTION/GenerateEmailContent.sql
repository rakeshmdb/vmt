FUNCTION GenerateEmailContent (
    templateCode VARCHAR2,
    contentParams ARRAY_TYPE
) RETURN VARCHAR2 AS
    emailContent       CLOB;
    backupEmailContent VARCHAR2(32000);
BEGIN
    SELECT CONTENT
      INTO emailContent
      FROM EMAIL_TEMPLATES
     WHERE TEMPLATE_CODE = templateCode;

    backupEmailContent := emailContent;
    emailContent := ProcessDynamicFields(emailContent, contentParams);
    RETURN emailContent;
EXCEPTION
    WHEN OTHERS THEN
        RETURN backupEmailContent;
END GenerateEmailContent;
