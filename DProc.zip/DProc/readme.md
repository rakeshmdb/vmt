# System Overview

This system is designed to manage and process beneficiary changes, including notifying relevant parties via email. The system is composed of several key procedures and functions that interact with a set of database tables to perform their operations.

## Procedures and Functions

### Root Procedure

#### `ProcessBeneficiaryChanges`
- **Purpose**: Handles the processing of beneficiary changes. It checks user permissions, compares new and existing beneficiary data, logs any changes..
- **Dependencies**:
  - **Child Procedures/Functions**:
    - `NotifyByEmail`
    - `TEMPLATE_EXTRACTION.GetSubject`
    - `TEMPLATE_EXTRACTION.GetContent`
    - `MAIL_ENGINE.InsertEmail`

### Child Procedures/Functions

#### `NotifyByEmail`
- **Purpose**: Sends email notifications about beneficiary changes. Constructs the email content and subject using templates and inserts the email into the mail queue.
- **Dependencies**:
  - `TEMPLATE_EXTRACTION.GetSubject`
  - `TEMPLATE_EXTRACTION.GetContent`
  - `MAIL_ENGINE.InsertEmail`

#### `TEMPLATE_EXTRACTION.GetSubject`
- **Purpose**: Generates the email subject based on a template code and dynamic fields.
- **Table Used**: `EMAIL_TEMPLATES`

#### `TEMPLATE_EXTRACTION.GetContent`
- **Purpose**: Generates the email content based on a template code and dynamic fields.
- **Table Used**: `EMAIL_TEMPLATES`

#### `MAIL_ENGINE.InsertEmail`
- **Purpose**: Inserts the email details into the mail queue and manages recipients.
- **Tables Used**: `MAIL_QUEUE`, `MAIL_RECIPIENTS`

## Tables Used

### `PARTNER_BENEFICIARIES`
- **Purpose**: Stores new beneficiary data.
- **Usage**: Fetched by `ProcessBeneficiaryChanges` to compare and process new beneficiary information.

### `PARTNER_BENEFICIARY_HISTORY`
- **Purpose**: Stores historical beneficiary data.
- **Usage**: Fetched by `ProcessBeneficiaryChanges` to compare with new beneficiary data.

### `BANK_DETAILS`
- **Purpose**: Stores detailed records of beneficiary changes and logs.
- **Usage**: Inserted by `ProcessBeneficiaryChanges` to log changes and updates.

### `PROFILE_ACCESS`
- **Purpose**: Manages user access permissions.
- **Usage**: Checked by `ProcessBeneficiaryChanges` to verify user permissions for processing changes.

### `EMAIL_TEMPLATES`
- **Purpose**: Stores email templates for subjects and content.
- **Usage**: Used by `TEMPLATE_EXTRACTION.GetSubject` and `TEMPLATE_EXTRACTION.GetContent` to generate email components.

### `MAIL_QUEUE`
- **Purpose**: Stores emails to be sent, including their content and metadata.
- **Usage**: Inserted by `MAIL_ENGINE.InsertEmail` to queue emails for sending.

### `MAIL_RECIPIENTS`
- **Purpose**: Stores email recipient details.
- **Usage**: Managed by `MAIL_ENGINE.InsertEmail` to specify who receives the emails.

### `EXTERNAL_PARTNERS`
- **Purpose**: Stores information about external partners, including their IDs and versioning details.
- **Usage**: Utilized by `ProcessBeneficiaryChanges` to access and manage external partner data relevant to beneficiary processing.

